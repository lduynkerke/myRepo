#include <stdio.h>
// TODO: Make the MPI functions and constants available

int main (int argc, char* argv[])
{
    // TODO: Initialise the MPI library

    // TODO: Obtain the process ID and the number of processes

    // TODO: Display the process ID and the number of processes
    printf("Hello world from rank ? of ?\n");

    // TODO: Deinitialise the MPI library

    return 0;
}
